This is essentially the upstream part of Software Properties GTK which handles drivers management, stripped out of the rest of the application and turned into a standalone tool.

This addresses the short-term need for a functional driver manager in Mint 15 and allows us to replace software-properties with mintsources.

Long term we'll see where this goes, whether it's worth continuing with it or whether it gets ditched :)
