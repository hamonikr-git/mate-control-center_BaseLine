
#include<gtk/gtk.h>

void setupTreeView(GtkWidget *treeview);
